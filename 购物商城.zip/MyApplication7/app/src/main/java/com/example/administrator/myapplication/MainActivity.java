package com.example.administrator.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;


public class MainActivity extends Activity {


    Button add;
    ImageView cat;

    private ListView mListView;
    private String[] titles = { "粗狗粮" , "优狗粮","普通狗粮"," 零食狗粮"};
    private String[] prices = { "￥199","￥2099","￥199", "￥299"};
    private  int[] icons = {R.drawable.a,R.drawable.b,R.drawable.c,R.drawable.d
            };
    protected  void  onCreate(Bundle savedInstanState) {
        super.onCreate(savedInstanState);
        setContentView(R.layout.activity_main);
        mListView = (ListView) findViewById(R.id.lv);


        MyBaseAdapter mAdapter = new MyBaseAdapter();
        mListView.setAdapter(mAdapter);


        cat=(ImageView)findViewById(R.id.cat);

    cat.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent=new Intent(MainActivity.this,catActivity.class);
            startActivity(intent);
        }
    });

    }





    class MyBaseAdapter extends  BaseAdapter {
            @Override
            public int getCount(){
                return  titles.length;
            }
            @Override
            public Object getItem(int position) {
                return  titles[position];
            }
            @Override
            public long getItemId(int position) {
                return  position;
            }
            @Override
            public View getView(int position, View convertView,ViewGroup parent) {
                View view = View.inflate(MainActivity.this,R.layout.list_item,null);
            TextView title = (TextView) view.findViewById(R.id.title);
            TextView price = (TextView) view.findViewById(R.id.price);
            ImageView iv = (ImageView) view.findViewById(R.id.iv);
            title.setText(titles[position]);
            price.setText(prices[position]);
            iv.setBackgroundResource(icons[position]);
            return view;
        }
    }








}