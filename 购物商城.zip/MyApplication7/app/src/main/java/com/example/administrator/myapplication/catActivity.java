package com.example.administrator.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class catActivity extends AppCompatActivity {



    Button add;
    ImageView cat;

    private ListView mListView;


    private String[] titles = { "孟加拉猫" , "暹罗猫"};
    private String[] prices = { "￥15999","￥5299"};
    private  int[] icons = {R.drawable.a,R.drawable.b
           };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cat);

        mListView = (ListView) findViewById(R.id.sh);



        MyBaseAdapter mAdapter = new MyBaseAdapter();
        mListView.setAdapter(mAdapter);

    }





    class MyBaseAdapter extends BaseAdapter {
        @Override
        public int getCount(){
            return  titles.length;
        }
        @Override
        public Object getItem(int position) {
            return  titles[position];
        }
        @Override
        public long getItemId(int position) {
            return  position;
        }
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = View.inflate(catActivity.this,R.layout.list_cat,null);
            TextView title = (TextView) view.findViewById(R.id.title);
            TextView price = (TextView) view.findViewById(R.id.price);
            ImageView iv = (ImageView) view.findViewById(R.id.iv);
            title.setText(titles[position]);
            price.setText(prices[position]);
            iv.setBackgroundResource(icons[position]);
            return view;
        }
    }
}
